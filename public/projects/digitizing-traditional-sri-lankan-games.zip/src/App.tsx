import { useState } from "react";
import HeroSection from "./components/HeroSection";
import GamesSection from "./components/GamesSection";
import ScriptsSection from "./components/ScriptsSection";
import Footer from "./components/Footer";
import AliyaGame from "./components/AliyaGame";
import KottaPoraGame from "./components/KottaPoraGame";

type ActiveGame = "none" | "aliya" | "kotta" | "kana";

// Simple Kana Mutti (mini game)
function KanaMuttiGame({ onBack }: { onBack: () => void }) {
  const [phase, setPhase] = useState<"intro" | "memorize" | "blindfolded" | "result">("intro");
  const [potPos] = useState({ x: 30 + Math.random() * 40, y: 25 + Math.random() * 30 });
  const [tapPos, setTapPos] = useState<{ x: number; y: number } | null>(null);
  const [timeLeft, setTimeLeft] = useState(3);
  const [score, setScore] = useState(0);
  const [distance, setDistance] = useState(0);

  const startMemorize = () => {
    setPhase("memorize");
    setTimeLeft(3);
    let t = 3;
    const interval = setInterval(() => {
      t -= 1;
      setTimeLeft(t);
      if (t <= 0) {
        clearInterval(interval);
        setPhase("blindfolded");
      }
    }, 1000);
  };

  const handleTap = (e: React.MouseEvent<HTMLDivElement>) => {
    if (phase !== "blindfolded") return;
    const rect = e.currentTarget.getBoundingClientRect();
    const x = ((e.clientX - rect.left) / rect.width) * 100;
    const y = ((e.clientY - rect.top) / rect.height) * 100;
    const dist = Math.sqrt((x - potPos.x) ** 2 + (y - potPos.y) ** 2);
    setTapPos({ x, y });
    setDistance(Math.round(dist * 10) / 10);
    const s = dist <= 5 ? 100 : dist <= 12 ? 80 : dist <= 20 ? 55 : Math.max(0, 30 - Math.floor(dist));
    setScore(s);
    setPhase("result");
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-sky-900 via-blue-800 to-indigo-900 flex flex-col">
      <div className="bg-black/30 backdrop-blur-sm text-white px-6 py-4 flex items-center gap-4">
        <button onClick={onBack} className="hover:bg-white/10 rounded-full p-2 transition-colors cursor-pointer">
          <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M15 19l-7-7 7-7" />
          </svg>
        </button>
        <div>
          <h2 className="text-xl font-extrabold">🏺 Kana Mutti</h2>
          <p className="text-blue-200 text-xs">Break the Clay Pot</p>
        </div>
      </div>

      <div className="flex-1 p-6 max-w-lg mx-auto w-full flex flex-col gap-6">
        {phase === "intro" && (
          <div className="flex-1 flex flex-col items-center justify-center text-center space-y-6">
            <div className="text-7xl">🏺</div>
            <h3 className="text-3xl font-extrabold text-white">Kana Mutti!</h3>
            <p className="text-blue-200 text-sm max-w-xs">
              Memorize the pot's position, then go blindfolded and smash it with a click!
            </p>
            <div className="bg-white/10 rounded-2xl p-5 w-full text-left space-y-3">
              {[
                { icon: "👀", text: "You have 3 seconds to memorize the pot's position." },
                { icon: "😵", text: "Screen goes blindfolded — recall where the pot was!" },
                { icon: "💥", text: "Click/tap to swing your stick at the remembered spot." },
                { icon: "🏆", text: "Closest hit wins the most points!" },
              ].map((item, i) => (
                <div key={i} className="flex gap-3 text-white/90 text-sm">
                  <span className="text-xl">{item.icon}</span>
                  <span>{item.text}</span>
                </div>
              ))}
            </div>
            <button
              onClick={startMemorize}
              className="px-10 py-4 bg-gradient-to-r from-sky-400 to-blue-500 text-white font-extrabold text-xl rounded-2xl shadow-2xl hover:scale-105 transition-all cursor-pointer"
            >
              👀 Start Memorizing!
            </button>
          </div>
        )}

        {phase === "memorize" && (
          <div className="flex-1 flex flex-col gap-4">
            <div className="text-center">
              <div className="text-6xl font-black text-yellow-300">{timeLeft}</div>
              <p className="text-white font-bold">Memorize the pot's position!</p>
            </div>
            <div className="relative flex-1 min-h-[300px] bg-sky-400/20 rounded-3xl overflow-hidden border-2 border-blue-400/40">
              <img src="/images/kana-mutti-hero.jpg" alt="Arena" className="absolute inset-0 w-full h-full object-cover opacity-50" />
              <div
                className="absolute animate-bounce"
                style={{ left: `${potPos.x}%`, top: `${potPos.y}%`, transform: "translate(-50%, -50%)" }}
              >
                <span className="text-5xl drop-shadow-2xl">🏺</span>
                <div className="absolute -inset-3 border-4 border-yellow-400 rounded-full animate-ping" />
              </div>
              <div className="absolute bottom-4 left-0 right-0 text-center">
                <span className="bg-black/60 text-white text-xs px-3 py-1 rounded-full">Remember this position!</span>
              </div>
            </div>
          </div>
        )}

        {phase === "blindfolded" && (
          <div className="flex-1 flex flex-col gap-4">
            <div className="text-center">
              <p className="text-2xl font-extrabold text-white">😵 Blindfolded!</p>
              <p className="text-blue-200 text-sm">Click where the pot was!</p>
            </div>
            <div
              className="relative flex-1 min-h-[300px] rounded-3xl overflow-hidden border-2 border-blue-400/20 cursor-crosshair"
              onClick={handleTap}
            >
              <img src="/images/kana-mutti-hero.jpg" alt="Arena" className="absolute inset-0 w-full h-full object-cover" style={{ filter: "blur(8px) brightness(0.3)" }} />
              <div className="absolute inset-0 bg-gray-900/60" />
              <div className="absolute inset-0 flex items-center justify-center">
                <p className="text-white/40 text-lg font-bold">Click to swing! 💥</p>
              </div>
            </div>
          </div>
        )}

        {phase === "result" && (
          <div className="flex-1 flex flex-col items-center justify-center space-y-6 text-center">
            <div className="text-6xl">{score >= 80 ? "💥" : score >= 55 ? "🎯" : "🤕"}</div>
            <div className="bg-white/10 backdrop-blur-sm rounded-3xl p-6 w-full">
              <h3 className="text-3xl font-extrabold text-white mb-1">
                {score >= 80 ? "Smashed it! 🏺💥" : score >= 55 ? "Almost! 🎯" : "Missed... 😅"}
              </h3>
              <p className="text-blue-200 text-sm mb-4">Distance: {distance} units away</p>
              <div className="text-7xl font-black text-transparent bg-clip-text bg-gradient-to-r from-sky-400 to-blue-300 mb-3">
                {score}
              </div>
              <div className="w-full bg-white/10 rounded-full h-3">
                <div className="h-full rounded-full bg-gradient-to-r from-sky-400 to-blue-500 transition-all duration-1000" style={{ width: `${score}%` }} />
              </div>
              <p className="text-blue-300/70 text-sm mt-2">{score}/100 points</p>

              {/* Show where pot was vs tap */}
              <div className="relative mt-4 h-32 rounded-2xl overflow-hidden">
                <img src="/images/kana-mutti-hero.jpg" alt="result" className="absolute inset-0 w-full h-full object-cover opacity-60" />
                <div className="absolute" style={{ left: `${potPos.x}%`, top: `${potPos.y}%`, transform: "translate(-50%, -50%)" }}>
                  <div className="w-6 h-6 bg-green-400/80 rounded-full border-2 border-green-300" />
                  <span className="absolute -bottom-5 left-1/2 -translate-x-1/2 text-xs text-green-200 whitespace-nowrap">🏺 Pot</span>
                </div>
                {tapPos && (
                  <div className="absolute" style={{ left: `${tapPos.x}%`, top: `${tapPos.y}%`, transform: "translate(-50%, -50%)" }}>
                    <div className="w-6 h-6 bg-red-400/80 rounded-full border-2 border-red-300" />
                    <span className="absolute -bottom-5 left-1/2 -translate-x-1/2 text-xs text-red-200 whitespace-nowrap">👆 You</span>
                  </div>
                )}
              </div>
            </div>
            <div className="flex gap-4 w-full">
              <button onClick={startMemorize} className="flex-1 py-3.5 bg-gradient-to-r from-sky-400 to-blue-500 text-white font-bold rounded-2xl shadow-lg hover:scale-105 transition-all cursor-pointer">
                🔄 Play Again
              </button>
              <button onClick={onBack} className="flex-1 py-3.5 bg-white/10 text-white font-bold rounded-2xl hover:bg-white/20 transition-all cursor-pointer">
                🏠 Home
              </button>
            </div>
          </div>
        )}
      </div>
    </div>
  );
}

export default function App() {
  const [activeGame, setActiveGame] = useState<ActiveGame>("none");

  const handlePlay = (game: string) => {
    setActiveGame(game as ActiveGame);
    window.scrollTo({ top: 0, behavior: "smooth" });
  };

  const handleBack = () => {
    setActiveGame("none");
  };

  if (activeGame === "aliya") return <AliyaGame onBack={handleBack} />;
  if (activeGame === "kotta") return <KottaPoraGame onBack={handleBack} />;
  if (activeGame === "kana") return <KanaMuttiGame onBack={handleBack} />;

  return (
    <main className="min-h-screen bg-white">
      <HeroSection onPlayGame={handlePlay} />
      <GamesSection onPlayGame={handlePlay} />
      <ScriptsSection />
      <Footer />
    </main>
  );
}
