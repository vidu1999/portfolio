import { useState, useEffect, useRef, useCallback } from "react";

type Phase = "intro" | "balance" | "attack" | "result";

export default function KottaPoraGame({ onBack }: { onBack: () => void }) {
  const [phase, setPhase] = useState<Phase>("intro");
  const [playerBalance, setPlayerBalance] = useState(100);
  const [opponentBalance, setOpponentBalance] = useState(100);
  const [powerMeter, setPowerMeter] = useState(0);
  const [powerDir, setPowerDir] = useState(1);
  const [_swipeReady, setSwipeReady] = useState(false);
  const [tilt, setTilt] = useState(0); // -100 to 100
  const [round, setRound] = useState(1);
  const [resultMsg, setResultMsg] = useState("");
  const [hits, setHits] = useState(0);
  const [combo, setCombo] = useState(0);
  const [showHitAnim, setShowHitAnim] = useState(false);
  const [mouseStart, setMouseStart] = useState<{ x: number; y: number } | null>(null);

  const powerRef = useRef(powerMeter);
  const phaseRef = useRef(phase);
  const tiltRef = useRef(tilt);
  powerRef.current = powerMeter;
  phaseRef.current = phase;
  tiltRef.current = tilt;

  // Power meter fill animation
  useEffect(() => {
    if (phase !== "balance") return;
    const interval = setInterval(() => {
      setPowerMeter((prev) => {
        const next = prev + powerDir * 2.2;
        if (next >= 100) { setPowerDir(-1); return 100; }
        if (next <= 0) { setPowerDir(1); return 0; }
        return next;
      });
    }, 30);
    return () => clearInterval(interval);
  }, [phase, powerDir]);

  // Tilt drift - simulate device tipping
  useEffect(() => {
    if (phase !== "balance") return;
    const interval = setInterval(() => {
      setTilt((prev) => {
        const drift = (Math.random() - 0.5) * 6;
        const next = Math.max(-100, Math.min(100, prev + drift));
        return next;
      });
    }, 400);
    return () => clearInterval(interval);
  }, [phase]);

  // Player loses balance if tilt too extreme
  useEffect(() => {
    if (phase !== "balance") return;
    const absTilt = Math.abs(tilt);
    if (absTilt > 75) {
      setPlayerBalance((prev) => Math.max(0, prev - 2));
    }
  }, [tilt, phase]);

  // Player balance death
  useEffect(() => {
    if (playerBalance <= 0 && phase === "balance") {
      setResultMsg("😵 You fell off the pole! Opponent wins this round.");
      setPhase("result");
    }
  }, [playerBalance, phase]);

  // Opponent balance death
  useEffect(() => {
    if (opponentBalance <= 0 && phase === "balance") {
      setResultMsg("🏆 You knocked the opponent off! You win!");
      setPhase("result");
    }
  }, [opponentBalance, phase]);

  // Opponent AI: occasionally attacks player
  useEffect(() => {
    if (phase !== "balance") return;
    const interval = setInterval(() => {
      if (Math.random() < 0.3) {
        const dmg = Math.floor(Math.random() * 12) + 5;
        setPlayerBalance((prev) => Math.max(0, prev - dmg));
        setTilt((prev) => prev + (Math.random() - 0.5) * 30);
      }
    }, 1800);
    return () => clearInterval(interval);
  }, [phase]);

  const handleCorrect = () => {
    setTilt((prev) => Math.max(-100, Math.min(100, prev + (Math.random() > 0.5 ? -10 : 10))));
  };

  const startGame = () => {
    setPlayerBalance(100);
    setOpponentBalance(100);
    setPowerMeter(0);
    setTilt(0);
    setHits(0);
    setCombo(0);
    setRound(1);
    setPhase("balance");
  };

  const handleSwipe = useCallback(() => {
    if (phaseRef.current !== "balance") return;
    const power = powerRef.current;
    if (power < 20) return;
    const dmg = Math.floor(power * 0.6 + Math.random() * 10);
    const newCombo = combo + 1;
    setCombo(newCombo);
    setHits((h) => h + 1);
    setShowHitAnim(true);
    setTimeout(() => setShowHitAnim(false), 600);
    setOpponentBalance((prev) => Math.max(0, prev - dmg * (newCombo > 2 ? 1.5 : 1)));
    setSwipeReady(false);
    setPowerMeter(0);
  }, [combo]);

  // Mouse swipe detection
  const handleMouseDown = (e: React.MouseEvent) => {
    setMouseStart({ x: e.clientX, y: e.clientY });
  };
  const handleMouseUp = (e: React.MouseEvent) => {
    if (!mouseStart) return;
    const dx = e.clientX - mouseStart.x;
    const dy = e.clientY - mouseStart.y;
    const dist = Math.sqrt(dx * dx + dy * dy);
    if (dist > 40) handleSwipe();
    setMouseStart(null);
  };

  const handleTouchStart = (e: React.TouchEvent) => {
    const t = e.touches[0];
    setMouseStart({ x: t.clientX, y: t.clientY });
  };
  const handleTouchEnd = (e: React.TouchEvent) => {
    if (!mouseStart) return;
    const t = e.changedTouches[0];
    const dx = t.clientX - mouseStart.x;
    const dy = t.clientY - mouseStart.y;
    const dist = Math.sqrt(dx * dx + dy * dy);
    if (dist > 40) handleSwipe();
    setMouseStart(null);
  };

  const balanceBarColor = (val: number) => {
    if (val > 60) return "from-green-400 to-emerald-500";
    if (val > 30) return "from-yellow-400 to-amber-500";
    return "from-red-400 to-rose-600";
  };

  const tiltPercent = ((tilt + 100) / 200) * 100;
  const isTiltDanger = Math.abs(tilt) > 60;

  return (
    <div className="min-h-screen bg-gradient-to-br from-green-900 via-emerald-800 to-teal-900 flex flex-col select-none">
      {/* Header */}
      <div className="bg-black/30 backdrop-blur-sm text-white px-6 py-4 flex items-center gap-4">
        <button onClick={onBack} className="hover:bg-white/10 rounded-full p-2 transition-colors cursor-pointer">
          <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M15 19l-7-7 7-7" />
          </svg>
        </button>
        <div>
          <h2 className="text-xl font-extrabold">🛏️ Kotta Pora</h2>
          <p className="text-emerald-300 text-xs">Digital Pillow Fight • Round {round}</p>
        </div>
        <div className="ml-auto text-right">
          <p className="text-xs text-white/60">Hits</p>
          <p className="text-xl font-black text-yellow-300">{hits}</p>
        </div>
      </div>

      <div className="flex-1 flex flex-col p-4 max-w-lg mx-auto w-full gap-4">
        {phase === "intro" && (
          <div className="flex-1 flex flex-col items-center justify-center space-y-6 text-center">
            <div className="text-7xl">🛏️</div>
            <h3 className="text-3xl font-extrabold text-white">Kotta Pora</h3>
            <p className="text-emerald-200 text-sm max-w-sm">
              The ancient Sri Lankan pillow fight! Balance on the pole, charge your power meter, and swipe to strike your opponent!
            </p>
            <div className="bg-white/10 backdrop-blur rounded-2xl p-5 text-left w-full space-y-3">
              {[
                { icon: "⚖️", text: "Keep yourself balanced — wild swings may tilt you!" },
                { icon: "⚡", text: "Watch the power bar fill up at the bottom." },
                { icon: "👊", text: "Swipe/click when it's full to strike!" },
                { icon: "🏆", text: "Knock the opponent's balance to zero to win!" },
              ].map((item, i) => (
                <div key={i} className="flex gap-3 text-white/90 text-sm">
                  <span className="text-xl">{item.icon}</span>
                  <span>{item.text}</span>
                </div>
              ))}
            </div>
            <button
              onClick={startGame}
              className="px-10 py-4 bg-gradient-to-r from-green-400 to-emerald-500 text-white font-extrabold text-xl rounded-2xl shadow-2xl hover:scale-105 transition-all cursor-pointer"
            >
              🥊 Start Fight!
            </button>
          </div>
        )}

        {phase === "balance" && (
          <div
            className="flex-1 flex flex-col gap-4"
            onMouseDown={handleMouseDown}
            onMouseUp={handleMouseUp}
            onTouchStart={handleTouchStart}
            onTouchEnd={handleTouchEnd}
          >
            {/* Opponent */}
            <div className="bg-white/10 backdrop-blur-sm rounded-2xl p-4">
              <div className="flex justify-between items-center mb-2">
                <p className="text-white font-bold text-sm">🤺 Opponent</p>
                <p className="text-white/70 text-sm">{Math.round(opponentBalance)}%</p>
              </div>
              <div className="h-4 bg-black/30 rounded-full overflow-hidden">
                <div
                  className={`h-full rounded-full bg-gradient-to-r ${balanceBarColor(opponentBalance)} transition-all duration-300`}
                  style={{ width: `${opponentBalance}%` }}
                />
              </div>
            </div>

            {/* Arena */}
            <div className="flex-1 relative flex items-center justify-center bg-black/20 backdrop-blur rounded-3xl overflow-hidden min-h-[240px]">
              <img
                src="/images/kotta-pora-hero.jpg"
                alt="Arena"
                className="absolute inset-0 w-full h-full object-cover opacity-40"
              />

              {/* Hit animation */}
              {showHitAnim && (
                <div className="absolute top-6 left-0 right-0 flex justify-center z-20 pointer-events-none">
                  <div className="bg-yellow-400/90 text-black font-black text-2xl px-6 py-2 rounded-full shadow-2xl animate-bounce">
                    💥 HIT! {combo > 2 ? `COMBO x${combo}!` : ""}
                  </div>
                </div>
              )}

              {/* Fighters */}
              <div className="relative z-10 flex gap-12 items-end justify-center">
                {/* Opponent */}
                <div className="flex flex-col items-center gap-1">
                  <div className={`text-6xl transition-transform duration-200 ${showHitAnim ? "translate-x-6" : ""}`}>
                    🧍
                  </div>
                  <p className="text-white/70 text-xs">Opponent</p>
                </div>
                {/* VS */}
                <div className="text-yellow-300 font-black text-2xl mb-6">VS</div>
                {/* Player */}
                <div
                  className="flex flex-col items-center gap-1"
                  style={{ transform: `rotate(${tilt * 0.3}deg)`, transition: "transform 0.3s ease" }}
                >
                  <div className="text-6xl">🧍</div>
                  <p className={`text-xs font-bold ${isTiltDanger ? "text-red-300 animate-pulse" : "text-white/70"}`}>
                    {isTiltDanger ? "⚠️ Falling!" : "You"}
                  </p>
                </div>
              </div>

              <p className="absolute bottom-3 text-white/50 text-xs">Swipe to strike!</p>
            </div>

            {/* Balance indicator */}
            <div>
              <div className="flex justify-between items-center mb-1">
                <p className="text-white/70 text-xs">⚖️ Your Balance</p>
                <p className={`text-xs font-bold ${isTiltDanger ? "text-red-300" : "text-white/70"}`}>
                  {Math.round(playerBalance)}%
                </p>
              </div>
              {/* Tilt bar */}
              <div className="h-3 bg-black/30 rounded-full overflow-hidden relative mb-1">
                <div
                  className="absolute h-full w-1.5 bg-white rounded-full shadow-lg transition-all duration-300"
                  style={{ left: `${tiltPercent}%`, transform: "translateX(-50%)" }}
                />
                <div className="absolute inset-0 border border-white/20 rounded-full" />
                <div className="absolute left-1/2 top-0 h-full w-0.5 bg-white/30 -translate-x-1/2" />
              </div>
              <div className="h-4 bg-black/30 rounded-full overflow-hidden">
                <div
                  className={`h-full rounded-full bg-gradient-to-r ${balanceBarColor(playerBalance)} transition-all duration-300`}
                  style={{ width: `${playerBalance}%` }}
                />
              </div>
            </div>

            {/* Power meter */}
            <div>
              <div className="flex justify-between items-center mb-1">
                <p className="text-white/70 text-xs">⚡ Power Meter</p>
                <p className="text-yellow-300 text-xs font-bold">{Math.round(powerMeter)}%</p>
              </div>
              <div className="h-6 bg-black/30 rounded-full overflow-hidden relative cursor-pointer">
                <div
                  className="h-full rounded-full bg-gradient-to-r from-yellow-400 via-orange-400 to-red-500 transition-none"
                  style={{ width: `${powerMeter}%` }}
                />
                {powerMeter >= 80 && (
                  <div className="absolute inset-0 flex items-center justify-center">
                    <span className="text-xs font-black text-white drop-shadow animate-pulse">⚡ SWIPE NOW!</span>
                  </div>
                )}
              </div>
            </div>

            {/* Correct button */}
            <button
              onClick={handleCorrect}
              className="py-3 bg-white/10 text-white/70 rounded-2xl text-sm hover:bg-white/20 transition-colors cursor-pointer"
            >
              ⚖️ Re-balance
            </button>
          </div>
        )}

        {phase === "result" && (
          <div className="flex-1 flex flex-col items-center justify-center space-y-6 text-center">
            <div className="text-7xl">{resultMsg.includes("win") ? "🏆" : "😵"}</div>
            <div className="bg-white/10 backdrop-blur-sm rounded-3xl p-6 w-full">
              <h3 className="text-2xl font-extrabold text-white mb-3">Round Over!</h3>
              <p className="text-emerald-200 text-sm mb-5">{resultMsg}</p>
              <div className="grid grid-cols-3 gap-4 mb-4">
                <div className="bg-black/20 rounded-2xl p-3">
                  <p className="text-3xl font-black text-yellow-300">{hits}</p>
                  <p className="text-white/60 text-xs">Total Hits</p>
                </div>
                <div className="bg-black/20 rounded-2xl p-3">
                  <p className="text-3xl font-black text-emerald-300">{Math.round(opponentBalance)}%</p>
                  <p className="text-white/60 text-xs">Opp Balance</p>
                </div>
                <div className="bg-black/20 rounded-2xl p-3">
                  <p className="text-3xl font-black text-orange-300">{Math.round(playerBalance)}%</p>
                  <p className="text-white/60 text-xs">Your Balance</p>
                </div>
              </div>
            </div>
            <div className="flex gap-4 w-full">
              <button
                onClick={startGame}
                className="flex-1 py-3.5 bg-gradient-to-r from-green-400 to-emerald-500 text-white font-bold rounded-2xl shadow-lg hover:scale-105 transition-all cursor-pointer"
              >
                🔄 Play Again
              </button>
              <button
                onClick={onBack}
                className="flex-1 py-3.5 bg-white/10 text-white font-bold rounded-2xl hover:bg-white/20 transition-all cursor-pointer"
              >
                🏠 Home
              </button>
            </div>
          </div>
        )}
      </div>
    </div>
  );
}
