import { useState } from "react";

const scripts = [
  {
    title: "🖼️ Kotta Pora — Visual Prompt",
    tag: "AI Art Generator",
    tagColor: "bg-purple-100 text-purple-700",
    icon: "🎨",
    content:
      '"A vibrant, 3D stylized mobile game interface for a Sri Lankan \'Kotta Pora\' (Pillow Fight), set in a lush green village during a golden sunset, traditional flags (Gok Kola) in the background, high-quality 4K render, playful cartoon style."',
  },
  {
    title: "🏺 Kana Mutti — Visual Prompt",
    tag: "AI Art Generator",
    tagColor: "bg-purple-100 text-purple-700",
    icon: "🎨",
    content:
      '"Close up of a decorated clay pot hanging from a rope, a digital \'target\' overlay for a \'Kana Mutti\' game, tropical coconut trees and blue sky background, bright festive colors, cinematic lighting."',
  },
  {
    title: "🐘 Aliyata Aha Thabeema — Game Logic",
    tag: "Game Script",
    tagColor: "bg-blue-100 text-blue-700",
    icon: "💻",
    content: `// Goal: Tap the exact coordinate where the elephant's eye should be.

1. Show "Blindfold" animation → screen goes blurry/dark
2. User moves finger → haptic feedback gets stronger near target
3. On Tap → Reveal the eye placement
4. Calculate Score: distance from (TargetX, TargetY)

score = max(0, 100 - distance * 2)
if (distance <= 3) → PERFECT (100 pts)
if (distance <= 8) → GREAT (85 pts)
if (distance <= 15) → GOOD (65 pts)`,
  },
  {
    title: "🛏️ Kotta Pora — Game Logic",
    tag: "Game Script",
    tagColor: "bg-blue-100 text-blue-700",
    icon: "💻",
    content: `// Goal: Balance using gyroscope & swipe to hit.

1. Balance: Keep phone level via accelerometer
   → tiltAngle = Math.abs(DeviceMotion.x + DeviceMotion.y)
   → if (tiltAngle > threshold) → balance -= penalty

2. Power Meter: A bar fills automatically at the bottom
   → powerMeter += fillRate * deltaTime

3. Action: When meter is full → "Swipe Forward" to strike
   → damage = powerMeter * 0.6 + random(0, 10)
   → opponent.balance -= damage

4. Win Condition:
   → if (opponent.balance <= 0) → WIN 🏆
   → if (player.balance <= 0) → LOSE 😵`,
  },
  {
    title: "🇱🇰 Happy New Year — Social Caption",
    tag: "Share Script",
    tagColor: "bg-green-100 text-green-700",
    icon: "📱",
    content: `"Bringing the village to the screen! 🥥✨ This Aluth Avurudu, we're keeping the traditions alive anywhere in the world. From the thrill of the Kotta Pora to the precision of Kana Mutti, the game is on! 🎮 🇱🇰 Wishing you a year filled with winning moments and sweet memories. Subha Aluth Avuruddak Wewa!"

#AluthAvurudu #SriLanka #AvuruduGames #DigitalTraditions #KottaPora #KanaMutti`,
  },
];

export default function ScriptsSection() {
  const [copied, setCopied] = useState<number | null>(null);

  const handleCopy = (text: string, idx: number) => {
    navigator.clipboard.writeText(text).then(() => {
      setCopied(idx);
      setTimeout(() => setCopied(null), 2000);
    });
  };

  return (
    <section className="py-20 px-6 bg-gradient-to-b from-gray-900 to-slate-900">
      <div className="max-w-4xl mx-auto">
        <div className="text-center mb-14">
          <span className="inline-block bg-white/10 text-white text-sm font-bold px-4 py-1.5 rounded-full mb-4">
            📜 Ready-to-Use Scripts
          </span>
          <h2 className="text-4xl md:text-5xl font-extrabold text-white mb-4">
            Prompts &{" "}
            <span className="text-yellow-400">Scripts</span>
          </h2>
          <p className="text-gray-400 text-lg max-w-xl mx-auto">
            Copy these AI image prompts, game logic scripts, and social captions to bring Avurudu traditions to life!
          </p>
        </div>

        <div className="space-y-6">
          {scripts.map((script, i) => (
            <div
              key={i}
              className="bg-white/5 border border-white/10 backdrop-blur-sm rounded-2xl overflow-hidden hover:border-white/20 transition-all duration-300"
            >
              <div className="flex items-center justify-between px-5 py-4 border-b border-white/10">
                <div className="flex items-center gap-3">
                  <span className="text-2xl">{script.icon}</span>
                  <div>
                    <h3 className="text-white font-bold text-sm md:text-base">{script.title}</h3>
                    <span className={`text-xs font-semibold px-2 py-0.5 rounded-full ${script.tagColor}`}>
                      {script.tag}
                    </span>
                  </div>
                </div>
                <button
                  onClick={() => handleCopy(script.content, i)}
                  className="flex items-center gap-2 px-4 py-2 rounded-xl bg-white/10 hover:bg-white/20 text-white text-sm font-medium transition-all cursor-pointer"
                >
                  {copied === i ? (
                    <>✅ Copied!</>
                  ) : (
                    <>
                      <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M8 16H6a2 2 0 01-2-2V6a2 2 0 012-2h8a2 2 0 012 2v2m-6 12h8a2 2 0 002-2v-8a2 2 0 00-2-2h-8a2 2 0 00-2 2v8a2 2 0 002 2z" />
                      </svg>
                      Copy
                    </>
                  )}
                </button>
              </div>
              <pre className="px-5 py-4 text-sm text-gray-300 whitespace-pre-wrap font-mono leading-relaxed overflow-x-auto">
                {script.content}
              </pre>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}
