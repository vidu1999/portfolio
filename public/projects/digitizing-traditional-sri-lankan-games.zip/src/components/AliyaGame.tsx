import { useState, useRef, useCallback } from "react";

const TARGET_X = 52; // percentage
const TARGET_Y = 38; // percentage

function getDistance(x1: number, y1: number, x2: number, y2: number) {
  return Math.sqrt((x1 - x2) ** 2 + (y1 - y2) ** 2);
}

function getScore(dist: number): number {
  if (dist <= 3) return 100;
  if (dist <= 8) return 85;
  if (dist <= 15) return 65;
  if (dist <= 25) return 40;
  return Math.max(0, 20 - Math.floor(dist / 5));
}

export default function AliyaGame({ onBack }: { onBack: () => void }) {
  const [phase, setPhase] = useState<"intro" | "blindfolded" | "result">("intro");
  const [tapPos, setTapPos] = useState<{ x: number; y: number } | null>(null);
  const [score, setScore] = useState(0);
  const [distance, setDistance] = useState(0);
  const [cursorPos, setCursorPos] = useState<{ x: number; y: number }>({ x: 50, y: 50 });
  const [pulseIntensity, setPulseIntensity] = useState(0);
  const gameAreaRef = useRef<HTMLDivElement>(null);

  const handleMouseMove = useCallback(
    (e: React.MouseEvent<HTMLDivElement>) => {
      if (phase !== "blindfolded") return;
      const rect = gameAreaRef.current?.getBoundingClientRect();
      if (!rect) return;
      const x = ((e.clientX - rect.left) / rect.width) * 100;
      const y = ((e.clientY - rect.top) / rect.height) * 100;
      setCursorPos({ x, y });
      const dist = getDistance(x, y, TARGET_X, TARGET_Y);
      const intensity = Math.max(0, 1 - dist / 50);
      setPulseIntensity(intensity);
    },
    [phase]
  );

  const handleTouchMove = useCallback(
    (e: React.TouchEvent<HTMLDivElement>) => {
      if (phase !== "blindfolded") return;
      e.preventDefault();
      const rect = gameAreaRef.current?.getBoundingClientRect();
      if (!rect) return;
      const touch = e.touches[0];
      const x = ((touch.clientX - rect.left) / rect.width) * 100;
      const y = ((touch.clientY - rect.top) / rect.height) * 100;
      setCursorPos({ x, y });
      const dist = getDistance(x, y, TARGET_X, TARGET_Y);
      const intensity = Math.max(0, 1 - dist / 50);
      setPulseIntensity(intensity);
    },
    [phase]
  );

  const handleTap = useCallback(
    (e: React.MouseEvent<HTMLDivElement> | React.TouchEvent<HTMLDivElement>) => {
      if (phase !== "blindfolded") return;
      const rect = gameAreaRef.current?.getBoundingClientRect();
      if (!rect) return;
      let x: number, y: number;
      if ("touches" in e) {
        const touch = (e as React.TouchEvent).changedTouches[0];
        x = ((touch.clientX - rect.left) / rect.width) * 100;
        y = ((touch.clientY - rect.top) / rect.height) * 100;
      } else {
        const me = e as React.MouseEvent;
        x = ((me.clientX - rect.left) / rect.width) * 100;
        y = ((me.clientY - rect.top) / rect.height) * 100;
      }
      const dist = getDistance(x, y, TARGET_X, TARGET_Y);
      setTapPos({ x, y });
      setDistance(Math.round(dist * 10) / 10);
      setScore(getScore(dist));
      setPhase("result");
    },
    [phase]
  );

  const handleStart = () => {
    setPhase("blindfolded");
    setTapPos(null);
    setScore(0);
    setCursorPos({ x: 50, y: 50 });
    setPulseIntensity(0);
  };

  const handleReset = () => {
    setPhase("intro");
    setTapPos(null);
    setScore(0);
    setDistance(0);
  };

  const getMedal = () => {
    if (score >= 85) return { icon: "🥇", label: "Perfect!", color: "text-yellow-500" };
    if (score >= 65) return { icon: "🥈", label: "Great!", color: "text-gray-400" };
    if (score >= 40) return { icon: "🥉", label: "Good Try!", color: "text-amber-600" };
    return { icon: "🎯", label: "Keep Trying!", color: "text-red-400" };
  };

  const pulseColor = pulseIntensity > 0.7
    ? "rgba(239,68,68,0.8)"
    : pulseIntensity > 0.4
    ? "rgba(251,146,60,0.7)"
    : pulseIntensity > 0.1
    ? "rgba(250,204,21,0.5)"
    : "transparent";

  return (
    <div className="min-h-screen bg-gradient-to-br from-amber-50 via-orange-50 to-yellow-100 flex flex-col">
      {/* Header */}
      <div className="bg-gradient-to-r from-amber-600 to-orange-500 text-white px-6 py-4 flex items-center gap-4 shadow-lg">
        <button onClick={onBack} className="hover:bg-white/20 rounded-full p-2 transition-colors cursor-pointer">
          <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M15 19l-7-7 7-7" />
          </svg>
        </button>
        <div>
          <h2 className="text-xl font-extrabold">🐘 Aliyata Aha Thabeema</h2>
          <p className="text-amber-100 text-xs">Pin the Eye on the Elephant</p>
        </div>
      </div>

      <div className="flex-1 p-4 md:p-8 max-w-2xl mx-auto w-full">
        {phase === "intro" && (
          <div className="space-y-6 text-center mt-8">
            <div className="text-7xl mb-4">🐘</div>
            <h3 className="text-3xl font-extrabold text-amber-800">How to Play</h3>
            <div className="bg-white rounded-3xl p-6 shadow-xl text-left space-y-4">
              {[
                { icon: "😵", text: "The screen will go blurry — you're blindfolded!" },
                { icon: "👆", text: "Move your finger/cursor around. The glow gets stronger as you get closer to the target." },
                { icon: "🎯", text: "Tap/click where you think the elephant's eye should be." },
                { icon: "🏆", text: "Score is calculated based on how close you are!" },
              ].map((item, i) => (
                <div key={i} className="flex gap-3 items-start">
                  <span className="text-2xl">{item.icon}</span>
                  <p className="text-gray-700 pt-1">{item.text}</p>
                </div>
              ))}
            </div>
            <button
              onClick={handleStart}
              className="px-10 py-4 bg-gradient-to-r from-amber-500 to-orange-500 text-white font-extrabold text-xl rounded-2xl shadow-2xl hover:scale-105 transition-all duration-200 cursor-pointer"
            >
              🐘 Start Game!
            </button>
          </div>
        )}

        {phase === "blindfolded" && (
          <div className="space-y-4">
            <div className="flex items-center justify-between">
              <div className="bg-amber-800/10 rounded-2xl px-4 py-2">
                <p className="text-amber-800 font-bold text-sm">😵 You are blindfolded!</p>
                <p className="text-amber-700 text-xs">Tap where the eye should be</p>
              </div>
              {/* Proximity indicator */}
              <div className="flex flex-col items-center gap-1">
                <div className="w-20 h-3 bg-gray-200 rounded-full overflow-hidden">
                  <div
                    className="h-full rounded-full transition-all duration-100"
                    style={{
                      width: `${pulseIntensity * 100}%`,
                      background: `linear-gradient(to right, #fbbf24, #ef4444)`,
                    }}
                  />
                </div>
                <p className="text-xs text-gray-500">🔥 Proximity</p>
              </div>
            </div>

            {/* Game Area */}
            <div
              ref={gameAreaRef}
              className="relative w-full aspect-[4/3] rounded-3xl overflow-hidden cursor-crosshair shadow-2xl select-none"
              style={{
                filter: "blur(0px)",
                background: "#f0e6d3",
              }}
              onMouseMove={handleMouseMove}
              onClick={handleTap}
              onTouchMove={handleTouchMove}
              onTouchEnd={handleTap}
            >
              {/* Elephant image with blur overlay */}
              <img
                src="/images/aliya-game.jpg"
                alt="Elephant"
                className="w-full h-full object-cover"
                style={{ filter: "blur(4px) brightness(0.7) saturate(0.6)" }}
                draggable={false}
              />

              {/* Blindfold overlay */}
              <div className="absolute inset-0 bg-gradient-to-br from-gray-900/60 via-gray-800/40 to-gray-900/60" />

              {/* Proximity glow circle */}
              <div
                className="pointer-events-none absolute transition-all duration-100 rounded-full"
                style={{
                  left: `${cursorPos.x}%`,
                  top: `${cursorPos.y}%`,
                  transform: "translate(-50%, -50%)",
                  width: `${80 + pulseIntensity * 60}px`,
                  height: `${80 + pulseIntensity * 60}px`,
                  background: `radial-gradient(circle, ${pulseColor} 0%, transparent 70%)`,
                  opacity: pulseIntensity * 2 + 0.3,
                  transition: "background 0.15s, width 0.15s, height 0.15s",
                }}
              />

              {/* Crosshair cursor */}
              <div
                className="pointer-events-none absolute"
                style={{
                  left: `${cursorPos.x}%`,
                  top: `${cursorPos.y}%`,
                  transform: "translate(-50%, -50%)",
                }}
              >
                <div className="w-6 h-6 border-2 border-white rounded-full opacity-90" />
                <div className="absolute top-1/2 left-0 w-full h-0.5 bg-white -translate-y-1/2 opacity-70" />
                <div className="absolute left-1/2 top-0 w-0.5 h-full bg-white -translate-x-1/2 opacity-70" />
              </div>

              <div className="absolute top-3 left-0 right-0 text-center">
                <span className="bg-black/50 text-white text-xs px-3 py-1 rounded-full backdrop-blur-sm">
                  👆 Tap the elephant's eye!
                </span>
              </div>
            </div>
          </div>
        )}

        {phase === "result" && (
          <div className="space-y-6 mt-4">
            <div className="text-center">
              <div className="text-6xl mb-2">{getMedal().icon}</div>
              <h3 className={`text-3xl font-extrabold ${getMedal().color}`}>{getMedal().label}</h3>
              <p className="text-gray-600 mt-1">Distance: {distance} units away</p>
            </div>

            {/* Score display */}
            <div className="bg-white rounded-3xl p-6 shadow-xl text-center">
              <p className="text-gray-500 text-sm font-medium uppercase tracking-widest mb-2">Your Score</p>
              <div className="text-8xl font-black text-transparent bg-clip-text bg-gradient-to-r from-amber-500 to-orange-600">
                {score}
              </div>
              <div className="mt-3 w-full bg-gray-100 rounded-full h-4 overflow-hidden">
                <div
                  className="h-full rounded-full bg-gradient-to-r from-amber-400 to-orange-500 transition-all duration-1000"
                  style={{ width: `${score}%` }}
                />
              </div>
              <p className="text-sm text-gray-400 mt-2">{score}/100 points</p>
            </div>

            {/* Result area showing where eye was */}
            <div className="relative w-full aspect-[4/3] rounded-3xl overflow-hidden shadow-xl">
              <img src="/images/aliya-game.jpg" alt="Elephant revealed" className="w-full h-full object-cover" />
              <div className="absolute inset-0 bg-black/20" />
              {/* Target */}
              <div
                className="absolute"
                style={{ left: `${TARGET_X}%`, top: `${TARGET_Y}%`, transform: "translate(-50%, -50%)" }}
              >
                <div className="w-8 h-8 border-4 border-green-400 rounded-full animate-pulse bg-green-400/30" />
                <span className="absolute -bottom-6 left-1/2 -translate-x-1/2 text-xs text-green-300 font-bold whitespace-nowrap bg-black/60 px-2 py-0.5 rounded">
                  ✅ Target
                </span>
              </div>
              {/* User tap */}
              {tapPos && (
                <div
                  className="absolute"
                  style={{ left: `${tapPos.x}%`, top: `${tapPos.y}%`, transform: "translate(-50%, -50%)" }}
                >
                  <div className="w-8 h-8 border-4 border-red-400 rounded-full bg-red-400/30" />
                  <span className="absolute -bottom-6 left-1/2 -translate-x-1/2 text-xs text-red-300 font-bold whitespace-nowrap bg-black/60 px-2 py-0.5 rounded">
                    👆 You
                  </span>
                </div>
              )}
            </div>

            <div className="flex gap-4">
              <button
                onClick={handleStart}
                className="flex-1 py-3.5 bg-gradient-to-r from-amber-500 to-orange-500 text-white font-bold rounded-2xl shadow-lg hover:scale-105 transition-all cursor-pointer"
              >
                🔄 Play Again
              </button>
              <button
                onClick={handleReset}
                className="flex-1 py-3.5 bg-gray-100 text-gray-700 font-bold rounded-2xl shadow hover:scale-105 transition-all cursor-pointer"
              >
                🏠 Main Menu
              </button>
            </div>
          </div>
        )}
      </div>
    </div>
  );
}
