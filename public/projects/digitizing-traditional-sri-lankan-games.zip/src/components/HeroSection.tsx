import { useEffect, useState } from "react";

const greetingText =
  "Bringing the village to the screen! 🥥✨ This Aluth Avurudu, we're keeping the traditions alive anywhere in the world. From the thrill of the Kotta Pora to the precision of Kana Mutti, the game is on! 🎮 🇱🇰 Wishing you a year filled with winning moments and sweet memories.";

export default function HeroSection({ onPlayGame }: { onPlayGame: (game: string) => void }) {
  const [displayed, setDisplayed] = useState("");
  const [idx, setIdx] = useState(0);
  const [showBadge, setShowBadge] = useState(false);

  useEffect(() => {
    if (idx < greetingText.length) {
      const timeout = setTimeout(() => {
        setDisplayed((prev) => prev + greetingText[idx]);
        setIdx((i) => i + 1);
      }, 28);
      return () => clearTimeout(timeout);
    } else {
      setTimeout(() => setShowBadge(true), 300);
    }
  }, [idx]);

  return (
    <section className="relative overflow-hidden min-h-screen flex flex-col items-center justify-center">
      {/* Background */}
      <div
        className="absolute inset-0 bg-cover bg-center"
        style={{ backgroundImage: "url('/images/avurudu-bg.jpg')" }}
      />
      <div className="absolute inset-0 bg-gradient-to-b from-orange-900/70 via-amber-800/60 to-yellow-900/80" />

      {/* Animated lanterns */}
      <div className="absolute top-8 left-0 right-0 flex justify-around pointer-events-none z-10">
        {["🪔", "🌺", "🪔", "🌸", "🪔", "🌺", "🪔"].map((icon, i) => (
          <span
            key={i}
            className="text-3xl animate-bounce"
            style={{ animationDelay: `${i * 0.2}s`, animationDuration: "2s" }}
          >
            {icon}
          </span>
        ))}
      </div>

      {/* Content */}
      <div className="relative z-20 text-center px-6 max-w-4xl mx-auto">
        {/* Title */}
        <div className="mb-4">
          <span className="inline-block bg-yellow-400/20 border border-yellow-400/40 text-yellow-200 text-sm font-semibold px-4 py-1.5 rounded-full backdrop-blur-sm mb-4">
            🇱🇰 Sinhala & Tamil New Year 2025
          </span>
        </div>
        <h1 className="text-5xl md:text-7xl font-extrabold text-white mb-3 drop-shadow-lg">
          <span className="text-yellow-300">Avurudu</span> Games
        </h1>
        <p className="text-xl md:text-2xl text-orange-100 font-light mb-2 drop-shadow">
          සුභ අලුත් අවුරුද්දක් වේවා!
        </p>
        <p className="text-lg text-yellow-200 font-semibold mb-8 drop-shadow">
          Subha Aluth Avuruddak Wewa! ✨
        </p>

        {/* Typewriter greeting */}
        <div className="bg-white/10 backdrop-blur-md border border-white/20 rounded-2xl p-5 mb-8 max-w-2xl mx-auto text-left shadow-xl">
          <p className="text-white/90 text-sm md:text-base leading-relaxed min-h-[72px]">
            {displayed}
            <span className="animate-pulse text-yellow-300">|</span>
          </p>
          {showBadge && (
            <div className="mt-3 flex gap-2 flex-wrap">
              {["#AluthAvurudu", "#SriLanka", "#AvuruduGames", "#DigitalTraditions"].map((tag) => (
                <span key={tag} className="text-xs bg-yellow-400/30 text-yellow-200 px-2 py-0.5 rounded-full">
                  {tag}
                </span>
              ))}
            </div>
          )}
        </div>

        {/* CTA Buttons */}
        <div className="flex flex-col sm:flex-row gap-4 justify-center">
          <button
            onClick={() => onPlayGame("aliya")}
            className="px-8 py-4 bg-gradient-to-r from-yellow-400 to-orange-500 text-white font-bold text-lg rounded-2xl shadow-2xl hover:scale-105 hover:shadow-orange-400/50 transition-all duration-300 cursor-pointer"
          >
            🐘 Play Aliyata Aha Thabeema
          </button>
          <button
            onClick={() => onPlayGame("kotta")}
            className="px-8 py-4 bg-gradient-to-r from-green-500 to-emerald-600 text-white font-bold text-lg rounded-2xl shadow-2xl hover:scale-105 hover:shadow-emerald-400/50 transition-all duration-300 cursor-pointer"
          >
            🛏️ Play Kotta Pora
          </button>
        </div>

        {/* Scroll arrow */}
        <div className="mt-12 animate-bounce">
          <svg className="w-6 h-6 text-yellow-300 mx-auto" fill="none" stroke="currentColor" viewBox="0 0 24 24">
            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M19 9l-7 7-7-7" />
          </svg>
          <p className="text-yellow-200/70 text-xs mt-1">Scroll to explore</p>
        </div>
      </div>
    </section>
  );
}
