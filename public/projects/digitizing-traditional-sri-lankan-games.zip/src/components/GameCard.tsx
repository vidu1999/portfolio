interface GameCardProps {
  title: string;
  subtitle: string;
  description: string;
  image: string;
  emoji: string;
  gradient: string;
  mechanic: {
    goal: string;
    steps: string[];
  };
  onPlay: () => void;
}

export default function GameCard({
  title,
  subtitle,
  description,
  image,
  emoji,
  gradient,
  mechanic,
  onPlay,
}: GameCardProps) {
  return (
    <div className="group relative bg-white rounded-3xl shadow-2xl overflow-hidden hover:scale-[1.02] transition-all duration-500 flex flex-col">
      {/* Image */}
      <div className="relative h-56 overflow-hidden">
        <img
          src={image}
          alt={title}
          className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-700"
        />
        <div className={`absolute inset-0 bg-gradient-to-t ${gradient} opacity-70`} />
        <div className="absolute top-4 left-4">
          <span className="text-4xl drop-shadow-lg">{emoji}</span>
        </div>
        <div className="absolute bottom-4 left-4 right-4">
          <h3 className="text-2xl font-extrabold text-white drop-shadow-lg">{title}</h3>
          <p className="text-white/80 text-sm font-medium">{subtitle}</p>
        </div>
      </div>

      {/* Body */}
      <div className="p-6 flex flex-col flex-1">
        <p className="text-gray-600 text-sm leading-relaxed mb-5">{description}</p>

        {/* Mechanic */}
        <div className="bg-amber-50 border border-amber-200 rounded-2xl p-4 mb-5 flex-1">
          <p className="text-amber-800 font-bold text-xs uppercase tracking-widest mb-2">🎯 Game Mechanic</p>
          <p className="text-amber-700 text-sm font-semibold mb-3">
            <span className="text-amber-500">Goal:</span> {mechanic.goal}
          </p>
          <ol className="space-y-2">
            {mechanic.steps.map((step, i) => (
              <li key={i} className="flex gap-2 text-sm text-gray-700">
                <span className="flex-shrink-0 w-5 h-5 bg-amber-400 text-white rounded-full flex items-center justify-center text-xs font-bold">
                  {i + 1}
                </span>
                <span>{step}</span>
              </li>
            ))}
          </ol>
        </div>

        {/* Play Button */}
        <button
          onClick={onPlay}
          className={`w-full py-3.5 rounded-2xl font-bold text-white text-lg shadow-lg hover:shadow-xl hover:scale-105 active:scale-95 transition-all duration-200 bg-gradient-to-r ${gradient.replace("from-", "from-").replace("to-transparent", "")} cursor-pointer`}
          style={{
            background: gradient.includes("orange")
              ? "linear-gradient(to right, #f97316, #ea580c)"
              : "linear-gradient(to right, #22c55e, #16a34a)",
          }}
        >
          Play Now {emoji}
        </button>
      </div>
    </div>
  );
}
