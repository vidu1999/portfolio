export default function Footer() {
  return (
    <footer className="bg-gray-950 text-white py-12 px-6">
      <div className="max-w-4xl mx-auto text-center">
        <div className="text-5xl mb-4">🇱🇰</div>
        <h3 className="text-2xl font-extrabold mb-2">Subha Aluth Avuruddak Wewa!</h3>
        <p className="text-yellow-400 text-lg font-semibold mb-1">සුභ අලුත් අවුරුද්දක් වේවා!</p>
        <p className="text-gray-400 text-sm mb-8 max-w-md mx-auto">
          Keeping traditions alive across the globe. From Sri Lanka to the world — the spirit of Avurudu never fades.
        </p>

        <div className="flex justify-center gap-8 text-3xl mb-8">
          {["🥥", "🪔", "🌺", "🎋", "🏺", "🛏️", "🐘"].map((icon, i) => (
            <span
              key={i}
              className="hover:scale-150 transition-transform cursor-default"
              style={{ animationDelay: `${i * 0.1}s` }}
            >
              {icon}
            </span>
          ))}
        </div>

        <div className="border-t border-white/10 pt-6 flex flex-col sm:flex-row justify-between items-center gap-3 text-sm text-gray-500">
          <p>© 2025 Avurudu Games • Built with 💛 for Sri Lanka</p>
          <div className="flex gap-4">
            {["#AluthAvurudu", "#SriLanka", "#AvuruduGames"].map((tag) => (
              <span key={tag} className="text-yellow-600/70 hover:text-yellow-400 transition-colors cursor-pointer">
                {tag}
              </span>
            ))}
          </div>
        </div>
      </div>
    </footer>
  );
}
