import GameCard from "./GameCard";

const games = [
  {
    id: "aliya",
    title: "Aliyata Aha Thabeema",
    subtitle: "Pin the Eye on the Elephant",
    description:
      "A beloved blindfolded tradition during Avurudu! Spin around, lose your bearings, and try to pin the eye exactly where it belongs on the elephant. The closer you are, the higher your score!",
    image: "/images/aliya-game.jpg",
    emoji: "🐘",
    gradient: "from-orange-600 to-amber-700",
    mechanic: {
      goal: "Tap the exact spot where the elephant's eye should be.",
      steps: [
        "Screen goes blurry — you're blindfolded!",
        "Move your finger/cursor around the screen.",
        "Glow gets stronger as you approach the target (haptic feedback).",
        "Tap to place the eye and reveal your score!",
      ],
    },
  },
  {
    id: "kotta",
    title: "Kotta Pora",
    subtitle: "Digital Pillow Fight",
    description:
      "Sri Lanka's most thrilling Avurudu game — now digital! Balance on your virtual log pole, charge your power meter, and swipe to send your opponent flying. Don't lose your balance!",
    image: "/images/kotta-pora-hero.jpg",
    emoji: "🛏️",
    gradient: "from-green-600 to-emerald-700",
    mechanic: {
      goal: "Knock opponent's balance to zero before they knock yours!",
      steps: [
        "Keep yourself balanced — tilt indicator shows your stability.",
        "Watch the power meter bar fill up automatically.",
        "When the meter is full, Swipe Forward to strike!",
        "If opponent's balance hits zero, they fall off — you win!",
      ],
    },
  },
  {
    id: "kana",
    title: "Kana Mutti",
    subtitle: "Break the Pot",
    description:
      "Blindfolded and armed with a stick, can you smash the clay pot? An iconic Avurudu game requiring memory, precision, and a little luck. Tap the correct spot to smash the decorated pot!",
    image: "/images/kana-mutti-hero.jpg",
    emoji: "🏺",
    gradient: "from-sky-600 to-blue-700",
    mechanic: {
      goal: "Hit the clay pot while blindfolded!",
      steps: [
        "Memorize the pot's location before the screen blurs.",
        "Screen goes blindfolded — you have 3 seconds.",
        "Tap where you remember the pot hanging!",
        "Score based on your accuracy — bulls-eye wins!",
      ],
    },
  },
];

interface GamesSectionProps {
  onPlayGame: (game: string) => void;
}

export default function GamesSection({ onPlayGame }: GamesSectionProps) {
  return (
    <section className="py-20 px-6 bg-gradient-to-b from-amber-50 to-orange-50">
      <div className="max-w-6xl mx-auto">
        {/* Section header */}
        <div className="text-center mb-14">
          <span className="inline-block bg-orange-100 text-orange-700 text-sm font-bold px-4 py-1.5 rounded-full mb-4">
            🎮 Traditional Games, Digitized
          </span>
          <h2 className="text-4xl md:text-5xl font-extrabold text-gray-900 mb-4">
            Avurudu <span className="text-orange-500">Game Zone</span>
          </h2>
          <p className="text-gray-600 text-lg max-w-2xl mx-auto">
            Experience the joy of Sri Lanka's most beloved New Year games — now playable anywhere in the world, right from your screen.
          </p>
        </div>

        {/* Cards */}
        <div className="grid md:grid-cols-3 gap-8">
          {games.map((game) => (
            <GameCard
              key={game.id}
              {...game}
              onPlay={() => onPlayGame(game.id)}
            />
          ))}
        </div>
      </div>
    </section>
  );
}
